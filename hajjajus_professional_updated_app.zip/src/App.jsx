export default function App() {
  const products = [
    {
      name: "Premium Hennah Design",
      price: "₦5,000",
      image:
        "https://images.unsplash.com/photo-1515377905703-c4788e51af15?q=80&w=1200&auto=format&fit=crop",
    },
    {
      name: "Beauty Products",
      price: "₦8,000",
      image:
        "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1200&auto=format&fit=crop",
    },
    {
      name: "Fashion Footwear",
      price: "₦12,000",
      image:
        "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1200&auto=format&fit=crop",
    },
    {
      name: "Custom Stickers",
      price: "₦3,500",
      image:
        "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop",
    },
  ];

  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <section className="relative overflow-hidden border-b border-yellow-600">
        <div className="absolute inset-0 bg-gradient-to-r from-yellow-700/20 to-black"></div>

        <div className="relative max-w-7xl mx-auto px-6 py-16 text-center">
          <h1 className="text-5xl md:text-7xl font-black mt-8 text-yellow-500 tracking-wide">
            HAJJAJU'S
          </h1>

          <p className="mt-6 text-lg md:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Hennah, Stickers, Fashion Materials, Beauty Products,
            Footwear and Modern Accessories.
          </p>

          <div className="mt-10 flex flex-col md:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/2349033062922"
              target="_blank"
              className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold px-8 py-4 rounded-2xl shadow-xl transition duration-300"
            >
              WhatsApp Order
            </a>
          </div>
        </div>
      </section>

      <section id="products" className="max-w-7xl mx-auto px-6 py-10">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-black text-yellow-500">
            Featured Products
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((item, index) => (
            <div
              key={index}
              className="bg-zinc-900 rounded-3xl overflow-hidden border border-yellow-600 shadow-xl"
            >
              <img
                src={item.image}
                alt={item.name}
                className="h-60 w-full object-cover"
              />

              <div className="p-6">
                <h3 className="text-2xl font-bold text-yellow-500">
                  {item.name}
                </h3>

                <p className="mt-3 text-xl text-gray-300">{item.price}</p>

                <a
                  href={`https://wa.me/2349033062922?text=Hello I want to order ${item.name}`}
                  target="_blank"
                  className="mt-6 block text-center bg-yellow-500 hover:bg-yellow-400 text-black font-bold py-3 rounded-2xl"
                >
                  Order Now
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
